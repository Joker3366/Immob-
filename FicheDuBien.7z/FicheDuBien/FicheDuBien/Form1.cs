﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FicheDuBien
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label_desc_surf_parcelle_Click(object sender, EventArgs e)
        {

        }

        private void label_desc_nb_pieces_Click(object sender, EventArgs e)
        {

        }

        private void desc_surface_habitable_Click(object sender, EventArgs e)
        {

        }

        private void label_desc_nb_chambres_Click(object sender, EventArgs e)
        {

        }
    }
}
